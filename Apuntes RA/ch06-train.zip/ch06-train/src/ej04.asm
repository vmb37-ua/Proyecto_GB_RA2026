;;==============================================================
;; Challenge 6 · Ejercicio 04 · Completa hud_show y hud_draw_hearts
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej04" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ04 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `hud_show` está en src/engine/ui/hud.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej04a::`.
;;   `hud_draw_hearts` está en src/engine/ui/hud.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej04b::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 4. El HUD vive en la window, una capa que se dibuja sobre el background y no hace scroll.
;;
;;   `hud_show`: coloca la window en la última fila de tiles de la pantalla.
;;   1. Escribe `HUD_WINDOW_X` en `rWX`.
;;   2. Escribe `HUD_WINDOW_Y` en `rWY`.
;;
;;   `hud_draw_hearts`: dibuja los corazones. `C` = corazones del héroe.
;;   1. Escribe `HEARTS_MAX` celdas seguidas, desde `HUD_HEARTS_CELL` (ya cargada en `HL`).
;;   2. Las primeras `C` llevan `TILE_HEART_FULL` y el resto, `TILE_HEART_EMPTY`.
;;
;; PASOS
;;   1. `hud_show`: `ld a, HUD_WINDOW_X` y `ldh [rWX], a`; lo mismo con `HUD_WINDOW_Y` y `rWY`.
;;   2. `hud_draw_hearts`: en cada vuelta, ¿quedan corazones llenos (`C` distinto de 0)? Elige el tile.
;;   3. Si era un corazón lleno, resta 1 a `C`.
;;   4. `ld [hl+], a` escribe la celda y avanza. `dec b` y repite mientras `B` no sea 0. `ret`.
;;
;; PISTAS
;;   - `ld a, tile` no cambia los flags: puedes comprobar `C` con `ld a, c` / `or a` y cargar el tile después.
;;   - `HL` ya apunta a la primera celda y `B` ya tiene el número de corazones por dibujar.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 04a", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Shows the window at the bottom of the screen.
;; ⚠️ The screen must be OFF (or be in VBLANK)
;; ❌ Modifies A
ej04a::   ;; = `hud_show`, que está en src/engine/ui/hud.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

SECTION "Ejercicio 04b", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Draws the hearts of the HUD: HEARTS_MAX cells, the first C full and the rest empty.
;; 📥 C = hearts the hero has
;; ❌ Modifies A, BC, HL
ej04b::   ;; = `hud_draw_hearts`, que está en src/engine/ui/hud.asm
   ld   b, HEARTS_MAX           ;; B = hearts to draw
   ld   hl, HUD_HEARTS_CELL     ;; HL = the first cell of the hearts

   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej04 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> rWY y rWX valían 0 y las 3 celdas de los corazones (HUD_HEARTS_CELL), EE. hud_show y después hud_draw_hearts con C = 2.
;; [MEM] rWY, rWX (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   FF40  .. .. .. .. .. .. .. ..|.. .. 88 07 .. .. .. ..|
;; [MEM] HUD_HEARTS_CELL (3 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   9C00  .. 45 45 46 .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  hud_show: rWY = HUD_WINDOW_Y = 136 (88 en hexadecimal) y rWX = HUD_WINDOW_X = 7. hud_draw_hearts con C = 2: dos corazones llenos (TILE_HEART_FULL = 45) y uno vacío (TILE_HEART_EMPTY = 46).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Igual, pero hud_draw_hearts con C = 0.
;; [MEM] rWY, rWX (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   FF40  .. .. .. .. .. .. .. ..|.. .. 88 07 .. .. .. ..|
;; [MEM] HUD_HEARTS_CELL (3 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   9C00  .. 46 46 46 .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  Con C = 0, las tres celdas son corazones vacíos (46).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ04 = 1): __ (SÍ / NO / NO LO SÉ)
