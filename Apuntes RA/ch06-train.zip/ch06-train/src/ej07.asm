;;==============================================================
;; Challenge 6 · Ejercicio 07 · Implementa sys_ai_choose
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej07" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ07 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `sys_ai_choose` está en src/sys/sys_ai.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej07::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 6. Decide qué hace una entidad a partir de un número aleatorio. 📥 `DE` = entidad, `A` = número aleatorio.
;;   1. Si el bit 7 de `A` vale 1 (la mitad de las veces), la entidad se queda quieta: `sys_physics_stop`.
;;   2. Si no, camina en la dirección que dicen los bits 6-5 de `A` (un número de 0 a 3, como `DIR_DOWN`, `DIR_UP`, `DIR_LEFT` y `DIR_RIGHT`): `sys_physics_walk` con `B` = esa dirección.
;;
;; PASOS
;;   1. Lleva los bits 7-5 de `A` a las posiciones 2-0 (por ejemplo, con `swap a` y `rrca`).
;;   2. `bit 2, a`: si vale 1, salta a `sys_physics_stop`.
;;   3. `and DIR_MASK` deja la dirección. Pásala a `B`.
;;   4. Salta a `sys_physics_walk`.
;;
;; PISTAS
;;   - `sys_physics_stop` y `sys_physics_walk` terminan con su propio `ret`: puedes saltar a ellos con `jp` en vez de llamarlos.
;;   - Hay más de un camino correcto para llegar a esos bits. Si el resultado es el mismo, vale.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 07", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; The AI decides what an entity does, from a random number: half of the times it
;; stands still, and the other half it walks in one of the 4 directions.
;;  - Bit 7 of the number: 1 = stand still (sys_physics_stop).
;;  - Bits 6-5 of the number: the direction to walk (sys_physics_walk, B = direction).
;; 📥 DE = entity, A = a random number
;; ❌ Modifies A, BC, HL
;; ⚠️ sys_physics_stop and sys_physics_walk end with their own ret
ej07::   ;; = `sys_ai_choose`, que está en src/sys/sys_ai.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej07 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> A = %10100101. Entidad 0 con VY = 1, VX = 0, mirando hacia abajo. DE = entidad 0.
;; [CPU]
;;    de = C000
;; [MEM] entity_array (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  C3 00 00 00 00 00 00 00|00 00 00 00 00 00 00 00|
;;  El bit 7 de A vale 1: la entidad se queda quieta. VY pasa de 1 a 0; VX y DIR no cambian.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> A = %01110000. Entidad 0 quieta, mirando hacia abajo. DE = entidad 0.
;; [CPU]
;;    de = C000
;; [MEM] entity_array (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  C3 00 00 00 00 00 01 00|03 00 00 00 00 00 00 00|
;;  El bit 7 vale 0 y los bits 6-5 valen %11 = DIR_RIGHT (3): camina a la derecha. DIR = 03 y VX = 1 (WALK_SPEED).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ07 = 1): __ (SÍ / NO / NO LO SÉ)
