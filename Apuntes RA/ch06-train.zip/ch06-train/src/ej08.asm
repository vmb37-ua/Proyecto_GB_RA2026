;;==============================================================
;; Challenge 6 · Ejercicio 08 · Implementa world_to_oam
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej08" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ08 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `world_to_oam` está en src/sys/sys_prerender.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej08::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 7. Las entidades guardan su posición en el mundo. Para dibujarlas hay que pasarla a coordenadas de la OAM: restar la cámara y sumar el offset de la OAM.
;;
;;   📥 `D` = Y del mundo, `E` = X del mundo.
;;   - `B` = `D` − cámara Y + `OAM_Y_OFFSET`
;;   - `C` = `E` − cámara X + `OAM_X_OFFSET`
;;
;;   Todo en 8 bits. No modifica `DE` ni `HL`.
;;
;; PASOS
;;   1. `call sys_camera_get`: te da `B` = cámara Y y `C` = cámara X. Ya no tienes tu entrada en `B` ni en `C`: por eso la entrada está en `D` y `E`.
;;   2. Y: `ld a, d` / `sub b` / `add OAM_Y_OFFSET` / `ld b, a`.
;;   3. X: lo mismo con `E` y `C`.
;;   4. `ret`.
;;
;; PISTAS
;;   - No compruebes si la entidad se ve. Si queda fuera de la pantalla, la resta "da la vuelta" en 8 bits y sale un valor que la consola no dibuja.
;;   - Cada resultado puede sobreescribir a su cámara: cuando has restado, ya no la necesitas.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 08", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Changes a position from WORLD coordinates to OAM coordinates:
;;    OAM = world - camera + offset   (offset: OAM_Y_OFFSET for Y, OAM_X_OFFSET for X)
;; All in 8 bits: if the position is outside the screen, the result wraps around to
;; values that the console does not draw (Y >= 160 or X >= 168).
;; 📥 D = world Y, E = world X
;; ⫷▬ B = OAM Y, C = OAM X
;; ❌ Modifies A, BC. Does NOT modify DE or HL
;; ⚠️ Use sys_camera_get
ej08::   ;; = `world_to_oam`, que está en src/sys/sys_prerender.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej08 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Cámara X = 50, Y = 20. D = 60 (Y), E = 100 (X). HL = 1234.
;; [CPU]
;;    bc = 383A
;;    de = 3C64
;;    hl = 1234
;;  B = 60 − 20 + 16 = 56 (38 en hexadecimal) y C = 100 − 50 + 8 = 58 (3A). DE y HL no cambian.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Cámara X = 50, Y = 20. D = 2 (Y), E = 3 (X). HL = 1234.
;; [CPU]
;;    bc = FED9
;;    de = 0203
;;    hl = 1234
;;  B = 2 − 20 + 16 = −2, que en 8 bits es 254 (FE), y C = 3 − 50 + 8 = −39, que es 217 (D9). Quedan fuera de la pantalla y no hizo falta comprobarlo. DE y HL no cambian.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ08 = 1): __ (SÍ / NO / NO LO SÉ)
