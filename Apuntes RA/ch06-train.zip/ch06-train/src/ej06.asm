;;==============================================================
;; Challenge 6 · Ejercicio 06 · Implementa sys_ai_one
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej06" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ06 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `sys_ai_one` está en src/sys/sys_ai.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej06::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 6. La IA de un enemigo: cada cierto tiempo, elige qué hacer. `DE` = entidad, que tiene `AI`.
;;   1. Resta 1 al `THINK` de la entidad. Si no ha llegado a 0, termina: todavía no toca elegir.
;;   2. Obtén un número aleatorio con `rng_next`.
;;   3. Pon `THINK` = `AI_THINK_MIN` + (el número aleatorio AND `AI_THINK_MASK`).
;;   4. Elige qué hacer con ese mismo número: llama a `sys_ai_choose` con `A` = el número y `DE` = la entidad.
;;
;; PASOS
;;   1. `HL` = `&entidad.THINK`: `ld h, d` / `ld a, e` / `add E_THINK` / `ld l, a`.
;;   2. `dec [hl]` y `ret nz`.
;;   3. `rng_next` modifica `A`, `B` y `HL`: guarda `HL` (`push` / `pop`) y el número (por ejemplo, en `C`).
;;   4. `and AI_THINK_MASK`, `add AI_THINK_MIN` y `ld [hl], a`.
;;   5. Recupera el número en `A` y salta a `sys_ai_choose` (su `ret` vuelve a quien te llamó).
;;
;; PISTAS
;;   - `dec [hl]` activa `Z` cuando el valor llega a 0.
;;   - `rng_next` no modifica `DE` ni `C`.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 06", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; AI system, for ONE entity: every so often, it chooses what to do next.
;; Its THINK counts the frames left before it chooses. When it reaches 0:
;;  - THINK = AI_THINK_MIN + a random number (0-31): the time until the next choice.
;;  - It chooses what to do with that same random number (sys_ai_choose).
;; ⚠️ Precondition: the entity has CMP_AI.
;; 📥 DE = entity
;; ❌ Modifies A, BC, HL
ej06::   ;; = `sys_ai_one`, que está en src/sys/sys_ai.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej06 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Entidad 0 con THINK = 1, quieta y mirando hacia abajo. rng_state = A5 5A. DE = entidad 0.
;; [CPU]
;;    de = C000
;; [MEM] entity_array (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  C3 00 00 00 00 FF 00 00|01 00 00 00 21 00 00 00|
;; [MEM] rng_state (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0C0  .. .. .. .. .. .. .. ..|.. .. .. 21 29 .. .. ..|
;;  THINK pasa de 1 a 0: toca elegir. rng_next consume un número (rng_state pasa a 21 29) y THINK = AI_THINK_MIN + (número AND AI_THINK_MASK) = 33 (21). Con ese mismo número, el bit 7 vale 0 y los bits 6-5 valen 01: la entidad camina hacia DIR_UP (DIR = 01, VY = −1 = FF).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Entidad 0 con THINK = 5, VY = 1, mirando hacia abajo. rng_state = A5 5A. DE = entidad 0.
;; [CPU]
;;    de = C000
;; [MEM] entity_array (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  C3 00 00 00 00 01 00 00|00 00 00 00 04 00 00 00|
;; [MEM] rng_state (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0C0  .. .. .. .. .. .. .. ..|.. .. .. A5 5A .. .. ..|
;;  THINK pasa de 5 a 4: todavía no toca elegir. No cambia nada más (VY sigue en 1) y no se llama a rng_next: rng_state sigue en A5 5A.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ06 = 1): __ (SÍ / NO / NO LO SÉ)
