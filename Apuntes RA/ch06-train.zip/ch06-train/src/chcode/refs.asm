;;==============================================================
;; Challenge 6 · Código del proyecto (en binario)
;;   ❌ No lo modifiques
;;==============================================================

SECTION "Ref ej01", ROM0
ref_ej01::
   INCBIN "chcode/bin/ref_ej01.bin"

SECTION "Ref ej02a", ROM0
ref_ej02a::
   INCBIN "chcode/bin/ref_ej02a.bin"

SECTION "Ref ej02b", ROM0
ref_ej02b::
   INCBIN "chcode/bin/ref_ej02b.bin"

SECTION "Ref ej03a", ROM0
ref_ej03a::
   INCBIN "chcode/bin/ref_ej03a.bin"

SECTION "Ref ej03b", ROM0
ref_ej03b::
   INCBIN "chcode/bin/ref_ej03b.bin"

SECTION "Ref ej04a", ROM0
ref_ej04a::
   INCBIN "chcode/bin/ref_ej04a.bin"

SECTION "Ref ej04b", ROM0
ref_ej04b::
   INCBIN "chcode/bin/ref_ej04b.bin"

SECTION "Ref ej05", ROM0
ref_ej05::
   INCBIN "chcode/bin/ref_ej05.bin"

SECTION "Ref ej06", ROM0
ref_ej06::
   INCBIN "chcode/bin/ref_ej06.bin"

SECTION "Ref ej07", ROM0
ref_ej07::
   INCBIN "chcode/bin/ref_ej07.bin"

SECTION "Ref ej08", ROM0
ref_ej08::
   INCBIN "chcode/bin/ref_ej08.bin"

SECTION "Ref ej09", ROM0
ref_ej09::
   INCBIN "chcode/bin/ref_ej09.bin"

SECTION "Ref ej10", ROM0
ref_ej10::
   INCBIN "chcode/bin/ref_ej10.bin"
