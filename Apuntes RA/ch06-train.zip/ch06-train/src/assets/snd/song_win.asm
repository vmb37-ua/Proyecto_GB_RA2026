include "include/hUGE.inc"

SECTION "Song: win", ROMX

SongWin::
db 6
dw order_cnt
dw order1, order2, order3, order4
dw duty_instruments, wave_instruments, noise_instruments
dw routines
dw waves

order_cnt: db 4
order1: dw P0,P4
order2: dw P1,P3
order3: dw P2,P3
order4: dw P3,P3

P0:
 dn C_5,1,$000
 dn ___,0,$000
 dn E_5,1,$000
 dn ___,0,$000
 dn G_5,1,$000
 dn ___,0,$000
 dn C_6,1,$000
 dn ___,0,$000
 dn G_5,1,$000
 dn ___,0,$000
 dn C_6,1,$000
 dn ___,0,$000
 dn E_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn D_6,1,$000
 dn ___,0,$000
 dn F_6,1,$000
 dn ___,0,$000
 dn A_6,1,$000
 dn ___,0,$000
 dn D_6,1,$000
 dn ___,0,$000
 dn F_6,1,$000
 dn ___,0,$000
 dn A_6,1,$000
 dn ___,0,$000
 dn F_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn E_6,1,$000
 dn ___,0,$000
 dn G_6,1,$000
 dn ___,0,$000
 dn C_7,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn B_6,1,$000
 dn ___,0,$000
 dn G_6,1,$000
 dn ___,0,$000
 dn E_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn C_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn E_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn G_6,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn C_7,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000

P1:
 dn C_4,1,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn D_4,1,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn ___,0,$037
 dn G_4,1,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn C_4,1,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047
 dn ___,0,$047

P2:
 dn C_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn G_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn D_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn A_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn G_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn D_5,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn C_4,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03
 dn C_5,1,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$E03

P3:
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000

P4:
 dn ___,0,$B02
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000
 dn ___,0,$000

duty_instruments:
itSquareinst1:
db 8
db 128
db 211
dw 0
db 128

itSquareinst2:
db 8
db 64
db 96
dw 0
db 128


wave_instruments:
itWaveinst1:
db 0
db 64
db 1
dw 0
db 128


noise_instruments:
itNoiseinst1:
db 0
dw 0
db 0
ds 2


routines:
__hUGE_Routine_0:

__end_hUGE_Routine_0:
ret

__hUGE_Routine_1:

__end_hUGE_Routine_1:
ret

__hUGE_Routine_2:

__end_hUGE_Routine_2:
ret

__hUGE_Routine_3:

__end_hUGE_Routine_3:
ret

__hUGE_Routine_4:

__end_hUGE_Routine_4:
ret

__hUGE_Routine_5:

__end_hUGE_Routine_5:
ret

__hUGE_Routine_6:

__end_hUGE_Routine_6:
ret

__hUGE_Routine_7:

__end_hUGE_Routine_7:
ret

__hUGE_Routine_8:

__end_hUGE_Routine_8:
ret

__hUGE_Routine_9:

__end_hUGE_Routine_9:
ret

__hUGE_Routine_10:

__end_hUGE_Routine_10:
ret

__hUGE_Routine_11:

__end_hUGE_Routine_11:
ret

__hUGE_Routine_12:

__end_hUGE_Routine_12:
ret

__hUGE_Routine_13:

__end_hUGE_Routine_13:
ret

__hUGE_Routine_14:

__end_hUGE_Routine_14:
ret

__hUGE_Routine_15:

__end_hUGE_Routine_15:
ret

waves:
wave0: db 0,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF
wave1: db 0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,0xFE,0xDC,0xBA,0x98,0x76,0x54,0x32,0x10
