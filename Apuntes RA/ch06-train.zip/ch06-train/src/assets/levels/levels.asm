;;==============================================================
;; Challenge 6 · Los niveles del juego
;; Un nivel son datos en la ROM: su mapa, su canción (la que suena mientras se juega, en assets/snd/),
;; dónde empieza el héroe, dónde se abre el portal cuando ya no quedan enemigos, y dónde
;; está cada enemigo. Las posiciones están en TILES: hay que multiplicarlas por 8 para
;; tener píxeles.
;; Para añadir un nivel: dibuja su mapa (maps.asm), elige o crea su canción,
;; escribe sus datos aquí, ponlo en LevelTable y sube NUM_LEVELS (scn_game.inc).
;; ❌ No lo modifiques
;;==============================================================
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Game: levels", ROM0

;; The levels, in order: the game plays them one after another
LevelTable::
   DW Level1, Level2, Level3
ASSERT (@ - LevelTable) == NUM_LEVELS * 2

;; Level 1: a meadow
Level1:
   DW Level1Map
   DW SongLevel1
   DB 4, 27                         ;; the hero starts at column 4, row 27
   DB 29, 2                         ;; the portal appears at column 29, row 2
   DB 3                             ;; 3 enemies:
   DB 18, 10,  27, 16,  19, 20

;; Level 2: some ruins, with their rooms
Level2:
   DW Level2Map
   DW SongLevel2
   DB 2, 26
   DB 29, 3
   DB 4
   DB 1, 5,  14, 22,  20, 12,  20, 1

;; Level 3: a dungeon
Level3:
   DW Level3Map
   DW SongLevel3
   DB 3, 27
   DB 27, 18
   DB 5
   DB 17, 23,  26, 8,  4, 3,  7, 25,  26, 24
