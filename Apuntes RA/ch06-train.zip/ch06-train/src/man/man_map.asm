;;==============================================================
;; Challenge 6 · Gestor del mapa (Map Manager)
;; El mapa del nivel actual: dibujarlo y saber qué hay en cada punto del mundo.
;; Solo sabe de tiles: no sabe qué entidades hay ni quién pregunta.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_map.inc"

SECTION "Map data", WRAM0
map_current::     DS 2                 ;; address (in ROM) of the map of the current level

SECTION "Map manager", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Loads a map: remembers it and draws it in the background of the screen.
;; 📥 HL = the map (MAP_SIZE tiles)
;; ⚠️ The screen must be OFF
;; ❌ Modifies A, BC, DE, HL
map_load::
   INCBIN "bin/map_load.bin"              ;; Rutina dada, en binario (17 bytes)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; EJERCICIO 03 (a): `map_tile_address`
;; La implementas TÚ, en src/ej03.asm (etiqueta `ej03a::`). Aquí solo hay un salto:
;; el resto del proyecto llama a `map_tile_address` y no necesita saber dónde está tu código.
map_tile_address::
   jp   go_ej03a             ;; Salta al ejercicio 03 (ver main.asm)
   ds   25, $00              ;; Relleno: las demás rutinas conservan su dirección

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; EJERCICIO 03 (b): `map_is_solid_at`
;; La implementas TÚ, en src/ej03.asm (etiqueta `ej03b::`). Aquí solo hay un salto:
;; el resto del proyecto llama a `map_is_solid_at` y no necesita saber dónde está tu código.
map_is_solid_at::
   jp   go_ej03b             ;; Salta al ejercicio 03 (ver main.asm)
   ds   10, $00              ;; Relleno: las demás rutinas conservan su dirección
