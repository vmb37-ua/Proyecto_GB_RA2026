;;==============================================================
;; Challenge 6 · Ejercicio 05 · Implementa game_enemies_spawn
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej05" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ05 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `game_enemies_spawn` está en src/scn/scn_game_rules.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej05::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 5. Crea a los enemigos de un nivel a partir de sus datos.
;;
;;   📥 `HL` = dirección del campo `LVL_ENEMIES` del nivel. Ahí hay un byte con cuántos enemigos son, seguido de su posición: dos bytes por enemigo (columna y fila, en tiles).
;;   1. Guarda el número de enemigos en `enemies_left`.
;;   2. Si no hay ninguno, termina.
;;   3. Para cada enemigo, crea una entidad desde `EnemyTemplate` en su columna y su fila, con `game_spawn_at`.
;;
;; PASOS
;;   1. `ld a, [hl+]` lee el número. Guárdalo en `enemies_left`. `HL` ya apunta a la primera posición.
;;   2. Pasa `HL` a `DE` (`game_spawn_at` no modifica `DE`, pero sí `HL`).
;;   3. Si el número es 0, `ret`.
;;   4. En cada vuelta: `C` = columna y `B` = fila (leídas de `[DE]`, avanzando `DE`), `HL` = `EnemyTemplate`, `call game_spawn_at`.
;;   5. Repite tantas veces como enemigos. Cuenta con un registro que `game_spawn_at` no modifique, o guárdalo en la pila.
;;
;; PISTAS
;;   - `game_spawn_at` modifica `A`, `BC` y `HL`. El contador de enemigos que te quedan no puede estar en ninguno de ellos mientras llamas.
;;   - `ld a, [de]` / `inc de` lee un byte y avanza.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 05", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Creates the enemies of a level. In the data of the level, a byte with how many
;; they are is followed by the position of each one: its column and row, in tiles.
;; It also remembers how many there are (enemies_left).
;; 📥 HL = &level.ENEMIES
;; ❌ Modifies A, BC, DE, HL
;; ⚠️ Use game_spawn_at, with EnemyTemplate
ej05::   ;; = `game_enemies_spawn`, que está en src/scn/scn_game_rules.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej05 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Los datos (en tst_data) son 3, (2, 3), (20, 4), (9, 30): tres enemigos como pares columna, fila. No hay entidades. HL = tst_data.
;; [MEM] enemies_left (1 byte)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0C0  .. 03 .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;; [MEM] entity_array (48 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  E7 18 10 68 00 00 00 04|00 68 00 00 01 00 00 00|
;;   C010  E7 20 A0 68 00 00 00 04|00 68 00 00 01 00 00 00|
;;   C020  E7 F0 48 68 00 00 00 04|00 68 00 00 01 00 00 00|
;;  enemies_left = 3. Tres enemigos, en el orden de los datos, con Y = fila × 8 y X = columna × 8. Primero (columna 2, fila 3): Y = 24 (18), X = 16 (10). Segundo (20, 4): Y = 32 (20), X = 160 (A0). Tercero (9, 30): Y = 240 (F0), X = 72 (48). El resto de cada entidad viene de EnemyTemplate.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Los datos son un solo byte: 0. enemies_left vale 99. HL = tst_data.
;; [MEM] enemies_left (1 byte)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0C0  .. 00 .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;; [MEM] entity_array (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C000  00 00 00 00 00 00 00 00|00 00 00 00 00 00 00 00|
;;  enemies_left = 0 y no se crea ninguna entidad.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ05 = 1): __ (SÍ / NO / NO LO SÉ)
