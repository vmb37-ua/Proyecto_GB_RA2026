;;==============================================================
;; Challenge 6 · Ejercicio 03 · Completa map_tile_address e implementa map_is_solid_at
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej03" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ03 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `map_tile_address` está en src/man/man_map.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej03a::`.
;;   `map_is_solid_at` está en src/man/man_map.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej03b::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 3. El mapa de un nivel es una tabla de 32 filas de 32 tiles (1.024 bytes) y cada tile mide 8 × 8 píxeles. `map_tile_address` dice dónde está el tile de un punto y `map_is_solid_at`, si ese tile es sólido.
;;
;;   `map_tile_address`: dirección del tile que cubre un punto del mundo.
;;   - 📥 `D` = Y y `E` = X del punto, en píxeles.
;;   - ⫷▬ `HL` = dirección de su tile en el mapa: `map_current + fila × 32 + columna`, con `fila = Y / 8` y `columna = X / 8`.
;;
;;   El código dado suma `map_current` a `HL` y vuelve. Tú calculas antes, en `HL`, el offset `fila × 32 + columna`:
;;   1. `fila × 32`: la Y sin sus 3 bits bajos es `fila × 8`; multiplícala por 4.
;;   2. `columna`: la X dividida entre 8.
;;   3. Suma la columna a `fila × 32`.
;;
;;   `map_is_solid_at`: ¿está un punto del mundo en un tile sólido? Son sólidos los tiles de `TILE_FIRST_SOLID` en adelante.
;;   - 📥 `D` = Y y `E` = X del punto, en píxeles.
;;   - ⫷▬ `NZ` si el punto está en un tile sólido y `Z` si está libre.
;;   - Modifica `A` y `HL`, pero no `DE`.
;;   1. Pide a `map_tile_address` la dirección del tile del punto.
;;   2. Lee el tile. Si es menor que `TILE_FIRST_SOLID`, está libre: devuelve `Z`.
;;   3. Si no, es sólido: devuelve `NZ`.
;;
;; PASOS
;;   1. Haz a mano la cuenta de un punto (por ejemplo, `Y` = 216, `X` = 32): fila, columna y offset.
;;   2. `ld a, d` y `and %11111000`: `A` = `fila × 8`. Pásalo a `L` y pon `H` a 0.
;;   3. Dos `add hl, hl` y `HL` = `fila × 32`.
;;   4. `ld a, e` y tres `srl a`: `A` = columna. Súmala a `L` (`add l`, `ld l, a`).
;;   5. `map_is_solid_at`: `call map_tile_address` y `ld a, [hl]`.
;;   6. `cp TILE_FIRST_SOLID`: si hay acarreo (menor), está libre. Si no, es sólido.
;;
;; PISTAS
;;   - `fila × 32` tiene sus 5 bits bajos a 0 y la columna es menor que 32: sumarlas nunca da acarreo, solo cambia `L`.
;;   - Si no sabes por dónde empezar, divide entre 8 con tres desplazamientos de bits a la derecha (`srl a`) y multiplica por 32 con `add hl, hl`.
;;   - Para devolver `Z` basta `xor a`; para devolver `NZ`, `or 1`. Cuidado: `cp` con un árbol (`TILE_TREE` = `TILE_FIRST_SOLID`) deja `Z` a 1.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 03a", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Where is the tile that covers a point of the world?
;; The map is a table of rows of MAP_WIDTH (32) tiles, and a tile is 8 x 8 pixels:
;;      tile row    = Y / 8        tile column = X / 8
;;      address     = map + row * 32 + column
;; 📥 D = Y, E = X (pixels of the world)
;; ⫷▬ HL = address of its tile in the map
;; ❌ Modifies A, HL
ej03a::   ;; = `map_tile_address`, que está en src/man/man_map.asm
   ;; ◉◉YOUR CODE◉◉

   ld   a, [map_current]        ;; \ HL += map_current: the address in the map
   add  l                       ;; |
   ld   l, a                    ;; |
   ld   a, [map_current + 1]    ;; |
   adc  h                       ;; |
   ld   h, a                    ;; /

   ret

SECTION "Ejercicio 03b", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Is the point solid? A tile is solid if it is TILE_FIRST_SOLID or higher:
;; the tiles are ordered in the tile block so that one comparison decides it.
;; 📥 D = Y, E = X (pixels of the world)
;; ⫷▬ NZ, the point is in a solid tile
;;    Z,  it is free
;; ❌ Modifies A, HL. Does NOT modify DE
;; ⚠️ Use map_tile_address
ej03b::   ;; = `map_is_solid_at`, que está en src/man/man_map.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej03 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Nivel 1: map_current = Level1Map (0188). D = 216 (Y), E = 32 (X). map_tile_address (HL se guarda en tst_log) y después, con HL = 1234, map_is_solid_at con el mismo punto.
;; [CPU]
;;    flag Z: 1   (1 = libre)
;;    hl = 04EC
;;    de = D820
;; [MEM] tst_log (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C800  EC 04 .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  map_tile_address: fila = 216 / 8 = 27 y columna = 32 / 8 = 4: 27 × 32 + 4 = 868 (364 en hexadecimal). HL = Level1Map + 364 = 04EC, guardado en tst_log como EC 04. map_is_solid_at: ese tile es un camino (TILE_PATH = 67, 43 en hexadecimal, menor que TILE_FIRST_SOLID = 72): libre, Z = 1. HL vuelve a ser 04EC y DE no cambia.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Nivel 1: map_current = Level1Map (0188). D = 255 (Y), E = 255 (X). Igual que P1.
;; [CPU]
;;    flag Z: 0   (0 = sólido)
;;    hl = 0587
;;    de = FFFF
;; [MEM] tst_log (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C800  87 05 .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  map_tile_address: fila = 31 y columna = 31: 31 × 32 + 31 = 1023 (3FF en hexadecimal). HL = Level1Map + 3FF = 0587, el último byte del mapa, guardado en tst_log como 87 05. map_is_solid_at: ese tile es un árbol (TILE_TREE = 72 = TILE_FIRST_SOLID): sólido, Z = 0. HL = 0587 y DE no cambia.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ03 = 1): __ (SÍ / NO / NO LO SÉ)
