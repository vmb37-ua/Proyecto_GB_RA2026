;;==============================================================
;; Challenge 6 · Sistema de IA (componente AI)
;; Las entidades con AI deciden solas hacia dónde ir: cada cierto tiempo eligen
;; una dirección al azar (o quedarse quietas). Como el jugador con INPUT, solo
;; deciden: caminar lo hace sys_physics.
;; ❌ No lo modifiques
;;==============================================================
INCLUDE "man/man_entity.inc"
INCLUDE "scn/scn_game.inc"

SECTION "System: ai", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; EJERCICIO 06: `sys_ai_one`
;; La implementas TÚ, en src/ej06.asm (etiqueta `ej06::`). Aquí solo hay un salto:
;; el resto del proyecto llama a `sys_ai_one` y no necesita saber dónde está tu código.
sys_ai_one::
   jp   go_ej06              ;; Salta al ejercicio 06 (ver main.asm)
   ds   19, $00              ;; Relleno: las demás rutinas conservan su dirección

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; EJERCICIO 07: `sys_ai_choose`
;; La implementas TÚ, en src/ej07.asm (etiqueta `ej07::`). Aquí solo hay un salto:
;; el resto del proyecto llama a `sys_ai_choose` y no necesita saber dónde está tu código.
sys_ai_choose::
   jp   go_ej07              ;; Salta al ejercicio 07 (ver main.asm)
   ds   11, $00              ;; Relleno: las demás rutinas conservan su dirección
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; AI system, for ALL the entities that have AI.
;; ❌ Modifies A, BC, DE, HL
sys_ai_update::
   INCBIN "bin/sys_ai_update.bin"         ;; Rutina dada, en binario (8 bytes)
