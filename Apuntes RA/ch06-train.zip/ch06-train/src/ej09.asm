;;==============================================================
;; Challenge 6 · Ejercicio 09 · Completa sys_prerender_one
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej09" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ09 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `sys_prerender_one` está en src/sys/sys_prerender.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej09::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 7. Prepara una entidad para dibujarla. Su imagen mide 16 × 16: se dibuja con 2 sprites de 8 × 16, uno al lado del otro, en la `shadow_oam`, a partir de `shadow_cursor`. 📥 `DE` = entidad.
;;
;;   El código dado calcula la posición en la OAM (`B` = Y, `C` = X de la mitad izquierda), descarta las entidades que invaden el HUD, carga `D` = `TILE`, `E` = `ATTR` y `HL` = dónde escribir, y escribe el sprite 0 (la mitad izquierda). Si la entidad está volteada (bit `ATTR_XFLIP` de `ATTR`), las dos mitades intercambian sus `X`: el sprite 0 va a la derecha y el sprite 1, a la izquierda. Tú escribes el resto:
;;   1. Sprite 1, la mitad derecha: `Y`, `X`, `TILE` + `TILES_PER_SPRITE` y `ATTR`. Su `X` es 8 píxeles más a la derecha (`SPRITE_WIDTH`), salvo que haya volteo.
;;   2. Guarda en `shadow_cursor` el sitio del siguiente sprite.
;;
;; PASOS
;;   1. Mira cómo escribe el sprite 0 su `X`: `C`, o `C` + `SPRITE_WIDTH` si hay volteo. El sprite 1 hace lo contrario.
;;   2. Sprite 1: `Y`, su `X`, su tile (`D` + `TILES_PER_SPRITE`) y `ATTR`.
;;   3. `ld a, l` y `ld [shadow_cursor], a`: `HL` ya está 8 bytes más allá.
;;   4. `ret`.
;;
;; PISTAS
;;   - El sprite 0 se salta el `add SPRITE_WIDTH` con `jr z`. Para el sprite 1, ¿cuál es la condición contraria?
;;   - `bit n, e` no modifica `E` ni `A`: puedes usarlo justo antes de decidir cuál es la X.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 09", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Prepares ONE entity to be drawn. Its image is 16 x 16 pixels, drawn with 2
;; sprites of 8 x 16 (each one shows two tiles, one above the other):
;;      sprite 0: the left half, its tile is entity.TILE
;;      sprite 1: the right half, 8 pixels to the right, its tile is entity.TILE + 2
;; If the image is mirrored (ATTR_XFLIP), each half is mirrored and they swap sides.
;; ⚠️ Precondition: the entity has CMP_SPRITE.
;; 📥 INPUT: DE: entity
;; ❌ May modify A, BC, DE, HL
ej09::   ;; = `sys_prerender_one`, que está en src/sys/sys_prerender.asm
   ld   h, d                    ;; \ HL = &entity.Y
   ld   a, e                    ;; |
   add  E_Y                     ;; |
   ld   l, a                    ;; /

   ld   a, [hl+]                ;; \ D = entity.Y (HL -> X)
   ld   d, a                    ;; /
   ld   e, [hl]                 ;; E = entity.X
   call world_to_oam            ;; B = OAM Y, C = OAM X of the left half

   ld   a, b                    ;; \ Does its bottom (OAM Y) reach the HUD, or
   cp   HUD_WINDOW_Y + 1        ;; | is it below the screen (the Y wrapped around)?
   ret  nc                      ;; / Yes: not drawn

   inc  l                       ;; \ D = entity.TILE
   ld   d, [hl]                 ;; /
   inc  l                       ;; \ E = entity.ATTR
   ld   e, [hl]                 ;; /

   ld   h, HIGH(shadow_oam)     ;; \ HL = where to write: the shadow OAM + the cursor
   ld   a, [shadow_cursor]      ;; |
   ld   l, a                    ;; /

   ld   a, b                    ;; \ Sprite 0: the left half
   ld   [hl+], a                ;; | Y
   ld   a, c                    ;; | X: normally on the left; mirrored, on the right
   bit  ATTR_XFLIP_BIT, e       ;; |
   jr   z, .left                ;; |
   add  SPRITE_WIDTH            ;; |
.left
   ld   [hl+], a                ;; |
   ld   a, d                    ;; | TILE
   ld   [hl+], a                ;; |
   ld   a, e                    ;; | ATTR
   ld   [hl+], a                ;; /

   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej09 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Cámara X = 50, Y = 20. Entidad 0 en (Y = 60, X = 100), TILE = 80, ATTR = 0. shadow_cursor = 40. Los 16 bytes desde shadow_oam + 40, EE. DE = entidad 0.
;; [MEM] shadow_oam + 40 (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C120  .. .. .. .. .. .. .. ..|38 3A 50 00 38 42 52 00|
;;   C130  EE EE EE EE EE EE EE EE|.. .. .. .. .. .. .. ..|
;; [MEM] shadow_cursor (1 byte)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0D0  .. .. 30 .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  La posición en la OAM es (Y = 56, X = 58). Sprite 0 (la mitad izquierda): 38 3A 50 00. Sprite 1 (la derecha): 38 42 52 00, con X = 58 + 8 y TILE = 80 + 2. shadow_cursor avanza 8: de 40 a 48 (30 en hexadecimal).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> Igual, pero ATTR = $20 (volteo en X).
;; [MEM] shadow_oam + 40 (16 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C120  .. .. .. .. .. .. .. ..|38 42 50 20 38 3A 52 20|
;;   C130  EE EE EE EE EE EE EE EE|.. .. .. .. .. .. .. ..|
;; [MEM] shadow_cursor (1 byte)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C0D0  .. .. 30 .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  Con el volteo, las mitades intercambian la X. Sprite 0: 38 42 50 20 (a la derecha). Sprite 1: 38 3A 52 20 (a la izquierda). Los dos llevan ATTR = 20. shadow_cursor = 48 (30).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ09 = 1): __ (SÍ / NO / NO LO SÉ)
