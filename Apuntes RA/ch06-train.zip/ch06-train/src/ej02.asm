;;==============================================================
;; Challenge 6 · Ejercicio 02 · Implementa camera_axis y sys_render_scroll
;;==============================================================
;;
;; CÓMO TRABAJAR
;;  1. Copia tu código del papel TAL CUAL en cada `◉◉YOUR CODE◉◉`. El resto ya está escrito.
;;  2. Prueba: en main.asm, DEF TEST EQUS "test_ej02" y make. BGB para en cada `ld b, b` (P1, P2).
;;     Compara CPU y MEM con el RESULTADO ESPERADO del final de este fichero.
;;  3. Juego: DEF TEST EQUS "game" y DEF EJ02 = 1.
;;  4. Rellena la autoevaluación.
;;
;; DÓNDE ESTÁ
;;   `camera_axis` está en src/sys/sys_camera.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej02a::`.
;;   `sys_render_scroll` está en src/sys/sys_render.asm. Allí solo hay un salto: tu código va AQUÍ, en `ej02b::`.
;;
;; QUÉ HAY QUE HACER
;;   Bloque 2. La cámara es la esquina de arriba a la izquierda de lo que se ve del mundo. `camera_axis` la calcula para un eje y `sys_render_scroll` la aplica al background.
;;
;;   `camera_axis`: la cámara es `posición − offset`, sin bajar de 0 y sin pasar del máximo.
;;   1. `A` = posición de la entidad en ese eje, `B` = offset (dónde queda la entidad en la pantalla), `C` = máximo de la cámara.
;;   2. Calcula `A − B`. Si el resultado baja de 0 (acarreo), devuelve 0.
;;   3. Si el resultado es menor que `C`, devuélvelo. Si no, devuelve `C`.
;;
;;   `sys_render_scroll`: mueve el background a la posición de la cámara.
;;   1. Pide la cámara con `sys_camera_get`.
;;   2. Escribe la cámara X en `rSCX` y la cámara Y en `rSCY`.
;;
;; PASOS
;;   1. `camera_axis`: `sub b`. Si hay acarreo, `xor a` y `ret`.
;;   2. `cp c`: si hay acarreo (`A < C`), `ret`. Si no, `ld a, c` y `ret`.
;;   3. `sys_render_scroll`: `call sys_camera_get`.
;;   4. Pasa por `A` para escribir cada registro: `ld a, c` y `ldh [rSCX], a`; `ld a, b` y `ldh [rSCY], a`.
;;
;; PISTAS
;;   - `cp c` calcula `A − C` sin guardar el resultado, y deja el acarreo a 1 si `A < C`.
;;   - `sys_camera_get` te da `B` = Y y `C` = X. Fíjate bien en cuál va a cada registro.
;;==============================================================
INCLUDE "engine/hardware.inc"
INCLUDE "assets/gfx/gfx.inc"
INCLUDE "man/man_entity.inc"
INCLUDE "man/man_map.inc"
INCLUDE "sys/sys_render.inc"
INCLUDE "engine/ui/hud.inc"
INCLUDE "scn/scn_game.inc"
INCLUDE "assets/levels/levels.inc"

SECTION "Ejercicio 02a", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; The camera for ONE axis: position - offset, not below 0 and not above the maximum.
;; 📥 A = position of the entity in that axis, B = offset, C = maximum of the camera
;; ⫷▬ A = the camera in that axis
;; ❌ Modifies A
ej02a::   ;; = `camera_axis`, que está en src/sys/sys_camera.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

SECTION "Ejercicio 02b", ROM0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Moves the background to the position of the camera: the scroll. The registers
;; rSCX and rSCY say which pixel of the background is at the top left of the screen.
;; ⚠️ Changing them in the middle of a frame tears the picture: do it in VBLANK
;; (or with the screen off). Use sys_camera_get
;; ❌ Modifies A, BC
ej02b::   ;; = `sys_render_scroll`, que está en src/sys/sys_render.asm
   ;; ◉◉YOUR CODE◉◉
   ret ;; ◀━REMOVE RET IF NEEDED

;; ==========================================================
;;  ENSAMBLA: ____  (SÍ / NO)
;; === CASOS DE PRUEBA   (test_ej02 en main.asm)
;;  * Comprobar que CPU y MEM coinciden con el valor esperado
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 1: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> camera_axis con A = 120, B = 72, C = 96. Después, sys_render_scroll con cam_x = 48 y cam_y = 30 (rSCY y rSCX valían FF).
;; [MEM] tst_log (1 byte)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C800  30 .. .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;; [MEM] rSCY, rSCX (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   FF40  .. .. 1E 30 .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  camera_axis: 120 − 72 = 48 (30 en hexadecimal), el valor de A, que se guarda en tst_log. sys_render_scroll: rSCX = cam_x = 48 (30) y rSCY = cam_y = 30 (1E).
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; * CASO 2: ____  (OK / Falla)
;;
;;        >>>>> RESULTADO ESPERADO (Comprobar) <<<<<
;; [PREVIO]> camera_axis con A = 30 y de nuevo con A = 250 (B = 72, C = 96). Después, sys_render_scroll con cam_x = 0 y cam_y = 0 (rSCY y rSCX valían FF).
;; [MEM] tst_log (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   C800  00 60 .. .. .. .. .. ..|.. .. .. .. .. .. .. ..|
;; [MEM] rSCY, rSCX (2 bytes)
;;         00 01 02 03 04 05 06 07|08 09 0A 0B 0C 0D 0E 0F|
;;   FF40  .. .. 00 00 .. .. .. ..|.. .. .. .. .. .. .. ..|
;;  camera_axis(30): 30 − 72 baja de 0 (acarreo) y devuelve 0. camera_axis(250): 250 − 72 = 178, que pasa del máximo, y devuelve 96 (60 en hexadecimal). sys_render_scroll deja rSCX = rSCY = 0.
;; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;; ==========================================================
;; EL JUEGO FUNCIONA CON MI EJERCICIO (DEF EJ02 = 1): __ (SÍ / NO / NO LO SÉ)
